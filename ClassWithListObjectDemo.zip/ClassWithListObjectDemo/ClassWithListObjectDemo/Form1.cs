﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ClassWithListObjectDemo
{
    public partial class Form1 : Form
    {
        Random rand = new Random();

        // Create a list of boxes
        List<Box> boxesList = new List<Box>();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnAddNewBox_Click(object sender, EventArgs e)
        {
            // Usualy you will get the data from textboxes
            // however you can also use random values
            double length = rand.Next(2, 8);
            double width = rand.Next(1, (int)length);
            double height = rand.Next(1, 5);
            double unitPrice = rand.Next(1, 4) + rand.NextDouble();

            // Create the box
            Box b = new Box(length, width, height, unitPrice);

            // Add it to the List in boxeslist
            boxesList.Add(b);

            //Display(b);
        }

        private void btnDisplayBoxes_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            foreach (var bx in boxesList)
            {
                Display(bx);
            }
        }
       
        private void btnChangeUnitPrice_Click(object sender, EventArgs e)
        {
            double newUnitPrice = double.Parse(txtUnitPrice.Text);
            int index = int.Parse(txtIndex.Text);
            Box box = boxesList[index];
            box.UnitPrice = newUnitPrice;
            listBox1.Items.Clear();
            Display(box);
        }

        private void Display(Box box)
        {
            string line = String.Format("{0,-4}{1,-4}{2,-4}{3,-10}{4,-7}{5,-9}{6:c}", box.Length, box.Width,
                box.Height, box.UnitPrice.ToString("c"), box.Volume(), box.Area(), box.Cost());

            listBox1.Items.Add(line);
        }

    }
}
