﻿namespace ClassWithListObjectDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listBox1 = new System.Windows.Forms.ListBox();
            this.btnAddNewBox = new System.Windows.Forms.Button();
            this.btnDisplayBoxes = new System.Windows.Forms.Button();
            this.btnChangeUnitPrice = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtIndex = new System.Windows.Forms.TextBox();
            this.txtUnitPrice = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // listBox1
            // 
            this.listBox1.FormattingEnabled = true;
            this.listBox1.Location = new System.Drawing.Point(13, 13);
            this.listBox1.Name = "listBox1";
            this.listBox1.Size = new System.Drawing.Size(546, 251);
            this.listBox1.TabIndex = 0;
            // 
            // btnAddNewBox
            // 
            this.btnAddNewBox.Location = new System.Drawing.Point(13, 280);
            this.btnAddNewBox.Name = "btnAddNewBox";
            this.btnAddNewBox.Size = new System.Drawing.Size(546, 53);
            this.btnAddNewBox.TabIndex = 1;
            this.btnAddNewBox.Text = "Add New Box";
            this.btnAddNewBox.UseVisualStyleBackColor = true;
            this.btnAddNewBox.Click += new System.EventHandler(this.btnAddNewBox_Click);
            // 
            // btnDisplayBoxes
            // 
            this.btnDisplayBoxes.Location = new System.Drawing.Point(15, 354);
            this.btnDisplayBoxes.Name = "btnDisplayBoxes";
            this.btnDisplayBoxes.Size = new System.Drawing.Size(543, 45);
            this.btnDisplayBoxes.TabIndex = 2;
            this.btnDisplayBoxes.Text = "Display All The Boxes";
            this.btnDisplayBoxes.UseVisualStyleBackColor = true;
            this.btnDisplayBoxes.Click += new System.EventHandler(this.btnDisplayBoxes_Click);
            // 
            // btnChangeUnitPrice
            // 
            this.btnChangeUnitPrice.Location = new System.Drawing.Point(117, 538);
            this.btnChangeUnitPrice.Name = "btnChangeUnitPrice";
            this.btnChangeUnitPrice.Size = new System.Drawing.Size(295, 53);
            this.btnChangeUnitPrice.TabIndex = 3;
            this.btnChangeUnitPrice.Text = "Change Unit price";
            this.btnChangeUnitPrice.UseVisualStyleBackColor = true;
            this.btnChangeUnitPrice.Click += new System.EventHandler(this.btnChangeUnitPrice_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 450);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(205, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Enter the index of box to change the price";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(362, 450);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "unit price";
            // 
            // txtIndex
            // 
            this.txtIndex.Location = new System.Drawing.Point(38, 485);
            this.txtIndex.Name = "txtIndex";
            this.txtIndex.Size = new System.Drawing.Size(100, 20);
            this.txtIndex.TabIndex = 6;
            // 
            // txtUnitPrice
            // 
            this.txtUnitPrice.Location = new System.Drawing.Point(337, 485);
            this.txtUnitPrice.Name = "txtUnitPrice";
            this.txtUnitPrice.Size = new System.Drawing.Size(100, 20);
            this.txtUnitPrice.TabIndex = 7;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(569, 597);
            this.Controls.Add(this.txtUnitPrice);
            this.Controls.Add(this.txtIndex);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnChangeUnitPrice);
            this.Controls.Add(this.btnDisplayBoxes);
            this.Controls.Add(this.btnAddNewBox);
            this.Controls.Add(this.listBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox listBox1;
        private System.Windows.Forms.Button btnAddNewBox;
        private System.Windows.Forms.Button btnDisplayBoxes;
        private System.Windows.Forms.Button btnChangeUnitPrice;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtIndex;
        private System.Windows.Forms.TextBox txtUnitPrice;
    }
}

