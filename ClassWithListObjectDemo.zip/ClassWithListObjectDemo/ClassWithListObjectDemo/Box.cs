﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClassWithListObjectDemo
{
    class Box
    {
        // Creat fields
        private double _length;
        private double _width;
        private double _height;
        private double _unitPrice;

        public Box(double length, double width, double height, double unitPrice)
        {
            _length = length;
            _width = width;
            _height = height;
            _unitPrice = unitPrice;
        }


        public double Length { get { return _length; } set { _length = value; } }
        public double Width { get { return _width; } set { _width = value; } }
        public double Height { get { return _height; } set { _width = value; } }

        public double UnitPrice
        {
            get
            {
                return _unitPrice;
            }
            set
            {
                if (value > 0) _unitPrice = value;
            }
        }

        // method
        public double Volume()
        {
            double v = _length * _width * _height;
            return v;
        }

        public double Area()
        {
            double a = 2 * (_length * _width) +
                2 * (_length * _height) +
                2 * (_width * _height);
            return a;
        }

        public double Cost()
        {
            double c = Volume() * _unitPrice;
            return c;
        }


    }
}
